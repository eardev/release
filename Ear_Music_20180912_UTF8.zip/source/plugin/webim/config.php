<?php
define('in_plugin_webim_open', '1');
define('in_plugin_webim_sec', '3600');
define('in_plugin_webim_num', '100');
define('in_plugin_webim_time', '6000');
?>