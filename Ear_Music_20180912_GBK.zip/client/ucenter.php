<?php
define('UC_CONNECT', '');
define('UC_DBHOST', '');
define('UC_DBUSER', '');
define('UC_DBPW', '');
define('UC_DBNAME', '');
define('UC_DBCHARSET', '');
define('UC_DBTABLEPRE', '');
define('UC_DBCONNECT', '0');
define('UC_KEY', '');
define('UC_API', '');
define('UC_CHARSET', '');
define('UC_IP', '');
define('UC_APPID', '');
define('UC_PPP', '20');
?>