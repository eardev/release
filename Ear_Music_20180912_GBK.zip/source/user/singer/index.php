<?php if(!defined('IN_ROOT')){exit('Access denied');} ?>
<?php global $db,$userlogined,$erduo_in_userid; ?>
<?php if(!$userlogined){header("location:".rewrite_mode('user.php/people/login/'));exit();} ?>
<?php
$letter_arr = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
$letter_arr1 = array(-20319, -20283, -19775, -19218, -18710, -18526, -18239, -17922, -1, -17417, -16474, -16212, -15640, -15165, -14922, -14914, -14630, -14149, -14090, -13318, -1, -1, -12838, -12556, -11847, -11055);
$letter_arr2 = array(-20284, -19776, -19219, -18711, -18527, -18240, -17923, -17418, -1, -16475, -16213, -15641, -15166, -14923, -14915, -14631, -14150, -14091, -13319, -12839, -1, -1, -12557, -11848, -11056, -2050);
$index = explode('/', $_SERVER['PATH_INFO']);
$cid = isset($index[3]) ? $index[3] : NULL;
if(in_array(strtoupper($cid), $letter_arr)){
$posarr = array_keys($letter_arr, strtoupper($cid));
$pos = $posarr[0];
$get = true;
$Arr = getuserpage("select * from ".tname('singer')." where UPPER(substring(".convert_using('in_name').",1,1))='".$letter_arr[$pos]."' and in_uid=".$erduo_in_userid." and in_passed=0 or ord(substring(".convert_using('in_name').",1,1))-65536>=".$letter_arr1[$pos]." and  ord(substring(".convert_using('in_name').",1,1))-65536<=".$letter_arr2[$pos]." and in_uid=".$erduo_in_userid." and in_passed=0", 10, 4);
}elseif(IsNum($cid)){
$get = $db->getone("select in_id from ".tname('singer_class')." where in_id=".$cid);
$Arr = getuserpage("select * from ".tname('singer')." where in_uid=".$erduo_in_userid." and in_passed=0 and in_classid=".$cid." order by in_addtime desc", 10, 4);
}else{
$get = true;
$Arr = getuserpage("select * from ".tname('singer')." where in_uid=".$erduo_in_userid." and in_passed=0 order by in_addtime desc", 10, 3);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>������� - <?php echo IN_NAME; ?></title>
<meta name="Keywords" content="<?php echo IN_KEYWORDS; ?>" />
<meta name="Description" content="<?php echo IN_DESCRIPTION; ?>" />
<style type="text/css">
@import url(<?php echo IN_PATH; ?>static/user/css/style.css);
@import url(<?php echo IN_PATH; ?>static/user/css/event.css);
</style>
</head>
<body>
<?php include 'source/user/people/top.php'; ?>
<div id="main">
<?php include 'source/user/people/left.php'; ?>
<div id="mainarea">
<h2 class="title"><img src="<?php echo IN_PATH; ?>static/user/images/icon/singer.gif">����</h2>
<div class="tabs_header">
<ul class="tabs">
<li class="active"><a href="<?php echo rewrite_mode('user.php/singer/index/'); ?>"><span>�������</span></a></li>
<li><a href="<?php echo rewrite_mode('user.php/singer/passed/'); ?>"><span>�������</span></a></li>
<li class="null"><a href="<?php echo rewrite_mode('user.php/singer/add/'); ?>">��������</a></li>
</ul>
</div>
<div id="content" style="width:640px;">
<?php if($get){ ?>
<div class="c_mgs"><div class="ye_r_t"><div class="ye_l_t"><div class="ye_r_b"><div class="ye_l_b">����������������ͨ����˵ĸ����б�</div></div></div></div></div>
<div class="h_status">
<?php
for($i=0;$i<26;$i++){
        if($i < 25){
                if(strtoupper($cid) == $letter_arr[$i]){
                        echo '<a href="'.rewrite_mode('user.php/singer/index/'.strtolower($letter_arr[$i]).'/').'" class="active">'.$letter_arr[$i].'</a><span class="pipe">|</span>';
                }else{
                        echo '<a href="'.rewrite_mode('user.php/singer/index/'.strtolower($letter_arr[$i]).'/').'">'.$letter_arr[$i].'</a><span class="pipe">|</span>';
                }
        }else{
                if(strtoupper($cid) == $letter_arr[$i]){
                        echo '<a href="'.rewrite_mode('user.php/singer/index/'.strtolower($letter_arr[$i]).'/').'" class="active">'.$letter_arr[$i].'</a>';
                }else{
                        echo '<a href="'.rewrite_mode('user.php/singer/index/'.strtolower($letter_arr[$i]).'/').'">'.$letter_arr[$i].'</a>';
                }
        }
}
?>
</div>
<?php
$result = $Arr[1];
$count = $Arr[2];
if($count == 0){
?>
<div class="c_form">û�����������֡�</div>
<?php }else{ ?>
<div class="event_list"><ol>
<?php
while ($row = $db->fetch_array($result)){
?>
<li>
<div class="event_icon"><a href="<?php echo getlink($row['in_id'], 'singer'); ?>" target="_blank"><img class="poster_pre" src="<?php echo geturl($row['in_cover'], 'cover'); ?>"></a></div>
<div class="event_content">
<h4 class="event_title"><a href="<?php echo getlink($row['in_id'], 'singer'); ?>" target="_blank"><?php echo $row['in_name']; ?></a></h4>
<ul>
<li><span class="gray">����:</span> <?php echo $row['in_hits']; ?></li>
<li><span class="gray">����:</span> <?php echo $row['in_addtime']; ?></li>
<li><span class="gray">����:</span> <a href="<?php echo getlink($row['in_classid'], 'singerclass'); ?>" target="_blank"><?php echo getfield('singer_class', 'in_name', 'in_id', $row['in_classid']); ?></a></li>
</ul>
</div>
</li>
<?php } ?>
</ol>
<?php echo $Arr[0]; ?>
</div>
<?php } ?>
<?php }else{ ?>
<div class="c_form">���಻���ڻ��ѱ�ɾ����</div>
<?php } ?>
</div>
<div id="sidebar" style="width:150px;">
<div class="cat">
<h3>���ַ���</h3>
<ul class="post_list line_list">
<?php
if(!IsNum($cid)){
        echo "<li class=\"current\"><a href=\"".rewrite_mode('user.php/singer/index/')."\">���޷���</a></li>";
}else{
        echo "<li><a href=\"".rewrite_mode('user.php/singer/index/')."\">���޷���</a></li>";
}
$res=$db->query("select * from ".tname('singer_class')." order by in_id asc");
if($res){
        while ($rows = $db->fetch_array($res)){
                if($cid == $rows['in_id']){
                        echo "<li class=\"current\"><a href=\"".rewrite_mode('user.php/singer/index/'.$rows['in_id'].'/')."\">".$rows['in_name']."</a></li>";
                }else{
                        echo "<li><a href=\"".rewrite_mode('user.php/singer/index/'.$rows['in_id'].'/')."\">".$rows['in_name']."</a></li>";
                }
        }
}
?>
</ul>
</div>
</div>
</div>
<div id="bottom"></div>
</div>
<?php include 'source/user/people/bottom.php'; ?>
</body>
</html>