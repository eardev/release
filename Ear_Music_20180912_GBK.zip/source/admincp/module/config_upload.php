<?php
if(!defined('IN_ROOT')){exit('Access denied');}
Administrator(2);
$action=SafeRequest("action","get");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>">
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>ȫ������</title>
<link href="static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
function $(obj) {return document.getElementById(obj);}
function change(type){
        if(type==1){
            $('upopen').style.display='';
        }else if(type==2){
            $('upopen').style.display='none';
        }else if(type==3){
            $('remotedisk').style.display='';
            $('remoteftp').style.display='none';
        }else if(type==4){
            $('remotedisk').style.display='none';
            $('remoteftp').style.display='';
        }
}
</script>
</head>
<body>
<?php
switch($action){
	case 'save':
		save();
		break;
	default:
		main();
		break;
	}
?>
</body>
</html>
<?php function main(){ ?>
<script type="text/javascript">parent.document.title = 'EarCMS Board �������� - ȫ�� - �ϴ���Ϣ';if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='ȫ��&nbsp;&raquo;&nbsp;�ϴ���Ϣ';</script>
<form method="post" action="?iframe=config_upload&action=save">
<input type="hidden" name="hash" value="<?php echo $_COOKIE['in_adminpassword']; ?>" />
<div class="container">
<div class="floattop"><div class="itemtitle"><h3>�ϴ���Ϣ</h3><ul class="tab1">
<li><a href="?iframe=config"><span>վ����Ϣ</span></a></li>
<li><a href="?iframe=config_cache"><span>������Ϣ</span></a></li>
<li class="current"><a href="?iframe=config_upload"><span>�ϴ���Ϣ</span></a></li>
<li><a href="?iframe=config_pay"><span>֧����Ϣ</span></a></li>
<li><a href="?iframe=config_user"><span>��Ա��Ϣ</span></a></li>
</ul></div></div><div class="floattopempty"></div>
<table class="tb tb2">
<tr><th colspan="15" class="partition">��������</th></tr>
<tr><td colspan="2" class="td27">�ϴ�����:</td></tr>
<tr><td class="vtop rowform">
<ul>
<?php if(IN_UPOPEN==1){echo "<li class=\"checked\">";}else{echo "<li>";} ?><input class="radio" type="radio" name="IN_UPOPEN" value="1" onclick="change(1);"<?php if(IN_UPOPEN==1){echo " checked";} ?>>&nbsp;����</li>
<?php if(IN_UPOPEN==0){echo "<li class=\"checked\">";}else{echo "<li>";} ?><input class="radio" type="radio" name="IN_UPOPEN" value="0" onclick="change(2);"<?php if(IN_UPOPEN==0){echo " checked";} ?>>&nbsp;�ر�</li>
</ul>
</td><td class="vtop tips2">�رպ�ȫվ���Զ��л���Զ���ϴ�</td></tr>
<tbody class="sub" id="upopen"<?php if(IN_UPOPEN<>1){echo " style=\"display:none;\"";} ?>>
<tr><td colspan="2" class="td27">MP3��������:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_UPMP3KBPS; ?>" name="IN_UPMP3KBPS" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">��λ��Kbps��0 Ϊ�رոù���</td></tr>
<tr><td colspan="2" class="td27">��Ƶ�����Ĵ�С:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_UPMUSICSIZE; ?>" name="IN_UPMUSICSIZE" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">MB</td></tr>
<tr><td colspan="2" class="td27">��Ƶ����������:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_UPMUSICEXT; ?>" name="IN_UPMUSICEXT"></td><td class="vtop tips2">�������ʱ���á�;������</td></tr>
<tr><td colspan="2" class="td27">��Ƶ�����Ĵ�С:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_UPVIDEOSIZE; ?>" name="IN_UPVIDEOSIZE" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">MB</td></tr>
<tr><td colspan="2" class="td27">��Ƶ����������:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_UPVIDEOEXT; ?>" name="IN_UPVIDEOEXT"></td><td class="vtop tips2">�������ʱ���á�;������</td></tr>
</tbody>
</table>
<table class="tb tb2">
<tr><th colspan="15" class="partition">Զ������</th></tr>
<tr><td colspan="2" class="td27">�ϴ�����:</td></tr>
<tr><td class="vtop rowform">
<ul>
<?php if(IN_REMOTE==1){echo "<li class=\"checked\">";}else{echo "<li>";} ?><input class="radio" type="radio" name="IN_REMOTE" value="1" onclick="change(3);"<?php if(IN_REMOTE==1){echo " checked";} ?>>&nbsp;�ƴ洢</li>
<?php if(IN_REMOTE==2){echo "<li class=\"checked\">";}else{echo "<li>";} ?><input class="radio" type="radio" name="IN_REMOTE" value="2" onclick="change(4);"<?php if(IN_REMOTE==2){echo " checked";} ?>>&nbsp;FTP</li>
</ul>
</td><td class="vtop tips2">�رձ����ϴ�ʱ���Զ��л���������</td></tr>
<tbody class="sub" id="remotedisk"<?php if(IN_REMOTE<>1){echo " style=\"display:none;\"";} ?>>
<tr><td colspan="2" class="td27">�ϴ���ʶ:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_REMOTEPK; ?>" name="IN_REMOTEPK"></td><td class="vtop tips2">�ƴ洢����չĿ¼</td></tr>
<tr><td colspan="2" class="td27">��������:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_REMOTEDK; ?>" name="IN_REMOTEDK"></td><td class="vtop tips2">�ԡ�<em class="lightnum">http://</em>����ͷ����<em class="lightnum">/</em>����β</td></tr>
<tr><td colspan="2" class="td27">Bucket:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_REMOTEBK; ?>" name="IN_REMOTEBK"></td><td class="vtop tips2">�ƴ洢�Ŀռ�����</td></tr>
<tr><td colspan="2" class="td27">AccessKey:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_REMOTEAK; ?>" name="IN_REMOTEAK"></td><td class="vtop tips2">�ƴ洢��ͨ����Կ</td></tr>
<tr><td colspan="2" class="td27">SecretKey:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_REMOTESK; ?>" name="IN_REMOTESK"></td><td class="vtop tips2">�ƴ洢��ͨ����Կ</td></tr>
</tbody>
<tbody class="sub" id="remoteftp"<?php if(IN_REMOTE<>2){echo " style=\"display:none;\"";} ?>>
<tr><td colspan="2" class="td27">FTP ��������ַ:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_REMOTEHOST; ?>" name="IN_REMOTEHOST"></td><td class="vtop tips2">������ FTP �������� IP ��ַ������</td></tr>
<tr><td colspan="2" class="td27">FTP �������˿�:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_REMOTEPORT; ?>" name="IN_REMOTEPORT" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">Ĭ��Ϊ 21</td></tr>
<tr><td colspan="2" class="td27">FTP �ʺ�:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_REMOTEUSER; ?>" name="IN_REMOTEUSER"></td><td class="vtop tips2">���ʺű����������Ȩ�ޣ���ȡ�ļ���д���ļ���ɾ���ļ�������Ŀ¼����Ŀ¼�̳�</td></tr>
<tr><td colspan="2" class="td27">FTP ����:</td></tr>
<tr><td class="vtop rowform"><input type="password" class="txt" value="<?php echo IN_REMOTEPW; ?>" name="IN_REMOTEPW"></td><td class="vtop tips2">���ڰ�ȫ���ǣ�FTP ���뽫������</td></tr>
<tr><td colspan="2" class="td27">����ģʽ(pasv)����:</td></tr>
<tr><td class="vtop rowform">
<select name="IN_REMOTEPASV">
<option value="0">��</option>
<option value="1"<?php if(IN_REMOTEPASV==1){echo " selected";} ?>>��</option>
</select>
</td><td class="vtop tips2">һ������·Ǳ���ģʽ���ɣ���������ϴ�ʧ�����⣬�ɳ��Դ򿪴�����</td></tr>
<tr><td colspan="2" class="td27">Զ�̸���Ŀ¼:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_REMOTEDIR; ?>" name="IN_REMOTEDIR"></td><td class="vtop tips2">Զ�̸���Ŀ¼�ľ���·��������� FTP ��Ŀ¼�����·����<em class="lightnum">ǰ��Ҫ��б��</em>��<em class="lightnum">/</em>������<em class="lightnum">.</em>��<em class="lightnum">��ʾ FTP ��Ŀ¼</em></td></tr>
<tr><td colspan="2" class="td27">Զ�̷��� URL:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_REMOTEURL; ?>" name="IN_REMOTEURL"></td><td class="vtop tips2">֧�� HTTP �� FTP Э�飬<em class="lightnum">��β��Ҫ��б��</em>��<em class="lightnum">/</em>�������ʹ�� FTP Э�飬FTP ����������֧�� PASV ģʽ��Ϊ�˰�ȫ�����ʹ�� FTP ���ӵ��ʺ������ÿ�дȨ�޺��б�Ȩ��</td></tr>
<tr><td colspan="2" class="td27">FTP ���䳬ʱʱ��:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_REMOTEOUT; ?>" name="IN_REMOTEOUT" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">��λ���룬0 Ϊ������Ĭ��</td></tr>
</tbody>
<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" value="�ύ" /></div></td></tr>
</table>
</div>
</form>
<?php }function save(){
if(!submitcheck('hash', 1)){ShowMessage("������·�������޷��ύ��",$_SERVER['PHP_SELF'],"infotitle3",3000,1);}
$str=file_get_contents('source/system/config.inc.php');
$str=preg_replace("/'IN_UPOPEN', '(.*?)'/", "'IN_UPOPEN', '".SafeRequest("IN_UPOPEN","post")."'", $str);
$str=preg_replace("/'IN_UPMP3KBPS', '(.*?)'/", "'IN_UPMP3KBPS', '".SafeRequest("IN_UPMP3KBPS","post")."'", $str);
$str=preg_replace("/'IN_UPMUSICSIZE', '(.*?)'/", "'IN_UPMUSICSIZE', '".SafeRequest("IN_UPMUSICSIZE","post")."'", $str);
$str=preg_replace("/'IN_UPMUSICEXT', '(.*?)'/", "'IN_UPMUSICEXT', '".SafeRequest("IN_UPMUSICEXT","post")."'", $str);
$str=preg_replace("/'IN_UPVIDEOSIZE', '(.*?)'/", "'IN_UPVIDEOSIZE', '".SafeRequest("IN_UPVIDEOSIZE","post")."'", $str);
$str=preg_replace("/'IN_UPVIDEOEXT', '(.*?)'/", "'IN_UPVIDEOEXT', '".SafeRequest("IN_UPVIDEOEXT","post")."'", $str);
$str=preg_replace("/'IN_REMOTE', '(.*?)'/", "'IN_REMOTE', '".SafeRequest("IN_REMOTE","post")."'", $str);
$str=preg_replace("/'IN_REMOTEPK', '(.*?)'/", "'IN_REMOTEPK', '".SafeRequest("IN_REMOTEPK","post")."'", $str);
$str=preg_replace("/'IN_REMOTEDK', '(.*?)'/", "'IN_REMOTEDK', '".SafeRequest("IN_REMOTEDK","post")."'", $str);
$str=preg_replace("/'IN_REMOTEBK', '(.*?)'/", "'IN_REMOTEBK', '".SafeRequest("IN_REMOTEBK","post")."'", $str);
$str=preg_replace("/'IN_REMOTEAK', '(.*?)'/", "'IN_REMOTEAK', '".SafeRequest("IN_REMOTEAK","post")."'", $str);
$str=preg_replace("/'IN_REMOTESK', '(.*?)'/", "'IN_REMOTESK', '".SafeRequest("IN_REMOTESK","post")."'", $str);
$str=preg_replace("/'IN_REMOTEHOST', '(.*?)'/", "'IN_REMOTEHOST', '".SafeRequest("IN_REMOTEHOST","post")."'", $str);
$str=preg_replace("/'IN_REMOTEPORT', '(.*?)'/", "'IN_REMOTEPORT', '".SafeRequest("IN_REMOTEPORT","post")."'", $str);
$str=preg_replace("/'IN_REMOTEUSER', '(.*?)'/", "'IN_REMOTEUSER', '".SafeRequest("IN_REMOTEUSER","post")."'", $str);
$str=preg_replace("/'IN_REMOTEPW', '(.*?)'/", "'IN_REMOTEPW', '".SafeRequest("IN_REMOTEPW","post")."'", $str);
$str=preg_replace("/'IN_REMOTEPASV', '(.*?)'/", "'IN_REMOTEPASV', '".SafeRequest("IN_REMOTEPASV","post")."'", $str);
$str=preg_replace("/'IN_REMOTEDIR', '(.*?)'/", "'IN_REMOTEDIR', '".SafeRequest("IN_REMOTEDIR","post")."'", $str);
$str=preg_replace("/'IN_REMOTEURL', '(.*?)'/", "'IN_REMOTEURL', '".SafeRequest("IN_REMOTEURL","post")."'", $str);
$str=preg_replace("/'IN_REMOTEOUT', '(.*?)'/", "'IN_REMOTEOUT', '".SafeRequest("IN_REMOTEOUT","post")."'", $str);
if(!$fp = fopen('source/system/config.inc.php', 'w')){ShowMessage("����ʧ�ܣ��ļ�{source/system/config.inc.php}û��д��Ȩ�ޣ�",$_SERVER['HTTP_REFERER'],"infotitle3",3000,1);}
$ifile=new iFile('source/system/config.inc.php', 'w');
$ifile->WriteFile($str, 3);
ShowMessage("��ϲ�������ñ���ɹ���",$_SERVER['HTTP_REFERER'],"infotitle2",1000,1);
}
?>