<?php
if(!defined('IN_ROOT')){exit('Access denied');}
Administrator(2);
$action=SafeRequest("action","get");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>">
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>ȫ������</title>
<link href="static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">function $(obj) {return document.getElementById(obj);}</script>
</head>
<body>
<?php
switch($action){
	case 'save':
		save();
		break;
	default:
		main();
		break;
	}
?>
</body>
</html>
<?php function main(){ ?>
<script type="text/javascript">parent.document.title = 'EarCMS Board �������� - ȫ�� - ֧����Ϣ';if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='ȫ��&nbsp;&raquo;&nbsp;֧����Ϣ';</script>
<form method="post" action="?iframe=config_pay&action=save">
<input type="hidden" name="hash" value="<?php echo $_COOKIE['in_adminpassword']; ?>" />
<div class="container">
<div class="floattop"><div class="itemtitle"><h3>֧����Ϣ</h3><ul class="tab1">
<li><a href="?iframe=config"><span>վ����Ϣ</span></a></li>
<li><a href="?iframe=config_cache"><span>������Ϣ</span></a></li>
<li><a href="?iframe=config_upload"><span>�ϴ���Ϣ</span></a></li>
<li class="current"><a href="?iframe=config_pay"><span>֧����Ϣ</span></a></li>
<li><a href="?iframe=config_user"><span>��Ա��Ϣ</span></a></li>
</ul></div></div><div class="floattopempty"></div>
<table class="tb tb2">
<tr><th colspan="15" class="partition">΢��</th></tr>
<tr><td colspan="2" class="td27">�̻���:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_WXMCHID; ?>" name="IN_WXMCHID"></td><td class="vtop tips2">΢��֧���̻��ţ�΢�����ͨ���ʼ��ڻ�ȡ</td></tr>
<tr><td colspan="2" class="td27">API ��Կ:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_WXKEY; ?>" name="IN_WXKEY"></td><td class="vtop tips2">��¼΢��֧���̻�ƽ̨���ʻ�����-���밲ȫ-API��ȫ</td></tr>
<tr><td colspan="2" class="td27">Ӧ�� ID:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_WXAPPID; ?>" name="IN_WXAPPID"></td><td class="vtop tips2">΢�ź�̨���������ģ���ȡAppId</td></tr>
<tr><td colspan="2" class="td27">Ӧ����Կ:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_WXAPPSECRET; ?>" name="IN_WXAPPSECRET"></td><td class="vtop tips2">΢�ź�̨���������ģ���ȡAppSecret</td></tr>
</table>
<table class="tb tb2">
<tr><th colspan="15" class="partition">֧����</th></tr>
<tr><td colspan="2" class="td27">���������� ID:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_ALIPAYID; ?>" name="IN_ALIPAYID"></td><td class="vtop tips2">��2088��ͷ��16λ������</td></tr>
<tr><td colspan="2" class="td27">��ȫ������:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_ALIPAYKEY; ?>" name="IN_ALIPAYKEY"></td><td class="vtop tips2">�����ֺ���ĸ��ɵ�32λ�ַ�</td></tr>
<tr><td colspan="2" class="td27">֧�����˺�:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_ALIPAYUID; ?>" name="IN_ALIPAYUID"></td><td class="vtop tips2">ǩԼ֧�����˺Ż�����֧�����ʻ�</td></tr>
</table>
<table class="tb tb2">
<tr><th colspan="15" class="partition">��ֵҵ��</th></tr>
<tr><td colspan="2" class="td27">��ҳ�ֵ���ʻ���:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_RMBPOINTS; ?>" name="IN_RMBPOINTS" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">���/ÿԪ</td></tr>
<tr><td colspan="2" class="td27">������ͨ�����ۼ�:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_VIPPOINTS; ?>" name="IN_VIPPOINTS" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">���/ÿ��</td></tr>
<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" value="�ύ" /></div></td></tr>
</table>
</div>
</form>
<?php }function save(){
if(!submitcheck('hash', 1)){ShowMessage("������·�������޷��ύ��",$_SERVER['PHP_SELF'],"infotitle3",3000,1);}
$str=file_get_contents('source/system/config.inc.php');
$str=preg_replace("/'IN_WXMCHID', '(.*?)'/", "'IN_WXMCHID', '".SafeRequest("IN_WXMCHID","post")."'", $str);
$str=preg_replace("/'IN_WXKEY', '(.*?)'/", "'IN_WXKEY', '".SafeRequest("IN_WXKEY","post")."'", $str);
$str=preg_replace("/'IN_WXAPPID', '(.*?)'/", "'IN_WXAPPID', '".SafeRequest("IN_WXAPPID","post")."'", $str);
$str=preg_replace("/'IN_WXAPPSECRET', '(.*?)'/", "'IN_WXAPPSECRET', '".SafeRequest("IN_WXAPPSECRET","post")."'", $str);
$str=preg_replace("/'IN_ALIPAYID', '(.*?)'/", "'IN_ALIPAYID', '".SafeRequest("IN_ALIPAYID","post")."'", $str);
$str=preg_replace("/'IN_ALIPAYKEY', '(.*?)'/", "'IN_ALIPAYKEY', '".SafeRequest("IN_ALIPAYKEY","post")."'", $str);
$str=preg_replace("/'IN_ALIPAYUID', '(.*?)'/", "'IN_ALIPAYUID', '".SafeRequest("IN_ALIPAYUID","post")."'", $str);
$str=preg_replace("/'IN_RMBPOINTS', '(.*?)'/", "'IN_RMBPOINTS', '".SafeRequest("IN_RMBPOINTS","post")."'", $str);
$str=preg_replace("/'IN_VIPPOINTS', '(.*?)'/", "'IN_VIPPOINTS', '".SafeRequest("IN_VIPPOINTS","post")."'", $str);
if(!$fp = fopen('source/system/config.inc.php', 'w')){ShowMessage("����ʧ�ܣ��ļ�{source/system/config.inc.php}û��д��Ȩ�ޣ�",$_SERVER['HTTP_REFERER'],"infotitle3",3000,1);}
$ifile=new iFile('source/system/config.inc.php', 'w');
$ifile->WriteFile($str, 3);
ShowMessage("��ϲ�������ñ���ɹ���",$_SERVER['HTTP_REFERER'],"infotitle2",1000,1);
}
?>