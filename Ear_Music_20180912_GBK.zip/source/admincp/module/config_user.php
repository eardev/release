<?php
if(!defined('IN_ROOT')){exit('Access denied');}
Administrator(2);
$action=SafeRequest("action","get");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>">
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>ȫ������</title>
<link href="static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
function $(obj) {return document.getElementById(obj);}
function change(type){
        if(type==1){
            $('qqopen').style.display='';
        }else if(type==2){
            $('qqopen').style.display='none';
        }
}
</script>
</head>
<body>
<?php
switch($action){
	case 'save':
		save();
		break;
	default:
		main();
		break;
	}
?>
</body>
</html>
<?php function main(){ ?>
<script type="text/javascript">parent.document.title = 'EarCMS Board �������� - ȫ�� - ��Ա��Ϣ';if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='ȫ��&nbsp;&raquo;&nbsp;��Ա��Ϣ';</script>
<form method="post" action="?iframe=config_user&action=save">
<input type="hidden" name="hash" value="<?php echo $_COOKIE['in_adminpassword']; ?>" />
<div class="container">
<div class="floattop"><div class="itemtitle"><h3>��Ա��Ϣ</h3><ul class="tab1">
<li><a href="?iframe=config"><span>վ����Ϣ</span></a></li>
<li><a href="?iframe=config_cache"><span>������Ϣ</span></a></li>
<li><a href="?iframe=config_upload"><span>�ϴ���Ϣ</span></a></li>
<li><a href="?iframe=config_pay"><span>֧����Ϣ</span></a></li>
<li class="current"><a href="?iframe=config_user"><span>��Ա��Ϣ</span></a></li>
</ul></div></div><div class="floattopempty"></div>
<table class="tb tb2">
<tr><th colspan="15" class="partition">QQ��¼</th></tr>
<tr><td colspan="2" class="td27">��¼����:</td></tr>
<tr><td class="vtop rowform">
<ul>
<?php if(IN_QQOPEN==1){echo "<li class=\"checked\">";}else{echo "<li>";} ?><input class="radio" type="radio" name="IN_QQOPEN" value="1" onclick="change(1);"<?php if(IN_QQOPEN==1){echo " checked";} ?>>&nbsp;����</li>
<?php if(IN_QQOPEN==0){echo "<li class=\"checked\">";}else{echo "<li>";} ?><input class="radio" type="radio" name="IN_QQOPEN" value="0" onclick="change(2);"<?php if(IN_QQOPEN==0){echo " checked";} ?>>&nbsp;�ر�</li>
</ul>
</td><td class="vtop lightnum">�ص���ַ��<?php echo "http://".$_SERVER['HTTP_HOST'].IN_PATH."source/pack/connect/redirect.php"; ?></td></tr>
<tbody class="sub" id="qqopen"<?php if(IN_QQOPEN<>1){echo " style=\"display:none;\"";} ?>>
<tr><td colspan="2" class="td27">APP ID:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_QQAPPID; ?>" name="IN_QQAPPID"></td><td class="vtop tips2">QQ������ͨ����Կ</td></tr>
<tr><td colspan="2" class="td27">APP KEY:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_QQAPPKEY; ?>" name="IN_QQAPPKEY"></td><td class="vtop tips2">QQ������ͨ����Կ</td></tr>
</tbody>
</table>
<table class="tb tb2">
<tr><th colspan="15" class="partition">��������</th></tr>
<tr><td colspan="2" class="td27">��Աע�Ὺ��:</td></tr>
<tr><td class="vtop rowform">
<select name="IN_REGOPEN">
<option value="0">�ر�</option>
<option value="1"<?php if(IN_REGOPEN==1){echo " selected";} ?>>����</option>
</select>
</td><td class="vtop tips2">�رպ�ǰ̨���޷�ʹ��ע�Ṧ��</td></tr>
<tr><td colspan="2" class="td27">��ԱͶ�忪��:</td></tr>
<tr><td class="vtop rowform">
<select name="IN_SHAREOPEN">
<option value="0">�ر�</option>
<option value="1"<?php if(IN_SHAREOPEN==1){echo " selected";} ?>>����</option>
</select>
</td><td class="vtop tips2">�رպ�ǰ̨���޷�ʹ��Ͷ�幦��</td></tr>
<tr><td colspan="2" class="td27">�û����߱�������:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_ONLINEHOLD; ?>" name="IN_ONLINEHOLD" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">��</td></tr>
<tr><td colspan="2" class="td27">��̬��¼��������:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_FEEDDAY; ?>" name="IN_FEEDDAY" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">��</td></tr>
<tr><td colspan="2" class="td27">�ÿͼ�¼��������:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_FOOTPRINTDAY; ?>" name="IN_FOOTPRINTDAY" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">��</td></tr>
<tr><td colspan="2" class="td27">��Ϣ��¼��������:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_MESSAGEDAY; ?>" name="IN_MESSAGEDAY" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">��</td></tr>
<tr><td colspan="2" class="td27">������¼��������:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_LISTENDAY; ?>" name="IN_LISTENDAY" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">��</td></tr>
<tr><td colspan="2" class="td27">�ʼ���¼��������:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_MAILDAY; ?>" name="IN_MAILDAY" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">��</td></tr>
</table>
<table class="tb tb2">
<tr><th colspan="15" class="partition">��������</th></tr>
<tr><td colspan="2" class="td27">ע���Ա��ʼ:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_REGPOINTS; ?>" name="IN_REGPOINTS" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">���</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_REGRANK; ?>" name="IN_REGRANK" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">����</td></tr>
<tr><td colspan="2" class="td27">ÿ���״ε�¼:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_LOGINDAYPOINTS; ?>" name="IN_LOGINDAYPOINTS" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">���</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_LOGINDAYRANK; ?>" name="IN_LOGINDAYRANK" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">����</td></tr>
<tr><td colspan="2" class="td27">ÿ�մ�ǩ��:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_SIGNDAYPOINTS; ?>" name="IN_SIGNDAYPOINTS" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">���*����ǩ������</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_SIGNDAYRANK; ?>" name="IN_SIGNDAYRANK" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">����*����ǩ������</td></tr>
<tr><td class="vtop rowform">
<select name="IN_SIGNVIPOPEN">
<option value="0">��</option>
<option value="1"<?php if(IN_SIGNVIPOPEN==1){echo " selected";} ?>>��</option>
</select>
</td><td class="vtop tips2">�Ƿ��������¸����ꡱ���ڽ�</td></tr>
<tr><td colspan="2" class="td27">�����ϴ�ͷ��:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_AVATARPOINTS; ?>" name="IN_AVATARPOINTS" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">���</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_AVATARRANK; ?>" name="IN_AVATARRANK" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">����</td></tr>
<tr><td colspan="2" class="td27">������֤����:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_MAILPOINTS; ?>" name="IN_MAILPOINTS" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">���</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_MAILRANK; ?>" name="IN_MAILRANK" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">����</td></tr>
<tr><td colspan="2" class="td27">�������:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_MUSICINPOINTS; ?>" name="IN_MUSICINPOINTS" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">���</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_MUSICINRANK; ?>" name="IN_MUSICINRANK" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">����</td></tr>
<tr><td colspan="2" class="td27">���ר��:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_SPECIALINPOINTS; ?>" name="IN_SPECIALINPOINTS" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">���</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_SPECIALINRANK; ?>" name="IN_SPECIALINRANK" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">����</td></tr>
<tr><td colspan="2" class="td27">��˸���:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_SINGERINPOINTS; ?>" name="IN_SINGERINPOINTS" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">���</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_SINGERINRANK; ?>" name="IN_SINGERINRANK" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">����</td></tr>
<tr><td colspan="2" class="td27">�����Ƶ:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_VIDEOINPOINTS; ?>" name="IN_VIDEOINPOINTS" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">���</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_VIDEOINRANK; ?>" name="IN_VIDEOINRANK" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">����</td></tr>
</table>
<table class="tb tb2">
<tr><th colspan="15" class="partition">�ͷ�����</th></tr>
<tr><td colspan="2" class="td27">ɾ������:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_MUSICOUTPOINTS; ?>" name="IN_MUSICOUTPOINTS" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">���</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_MUSICOUTRANK; ?>" name="IN_MUSICOUTRANK" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">����</td></tr>
<tr><td colspan="2" class="td27">ɾ��ר��:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_SPECIALOUTPOINTS; ?>" name="IN_SPECIALOUTPOINTS" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">���</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_SPECIALOUTRANK; ?>" name="IN_SPECIALOUTRANK" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">����</td></tr>
<tr><td colspan="2" class="td27">ɾ������:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_SINGEROUTPOINTS; ?>" name="IN_SINGEROUTPOINTS" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">���</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_SINGEROUTRANK; ?>" name="IN_SINGEROUTRANK" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">����</td></tr>
<tr><td colspan="2" class="td27">ɾ����Ƶ:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_VIDEOOUTPOINTS; ?>" name="IN_VIDEOOUTPOINTS" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">���</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_VIDEOOUTRANK; ?>" name="IN_VIDEOOUTRANK" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">����</td></tr>
<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" value="�ύ" /></div></td></tr>
</table>
</div>
</form>
<?php }function save(){
if(!submitcheck('hash', 1)){ShowMessage("������·�������޷��ύ��",$_SERVER['PHP_SELF'],"infotitle3",3000,1);}
$str=file_get_contents('source/system/config.inc.php');
$str=preg_replace("/'IN_QQOPEN', '(.*?)'/", "'IN_QQOPEN', '".SafeRequest("IN_QQOPEN","post")."'", $str);
$str=preg_replace("/'IN_QQAPPID', '(.*?)'/", "'IN_QQAPPID', '".SafeRequest("IN_QQAPPID","post")."'", $str);
$str=preg_replace("/'IN_QQAPPKEY', '(.*?)'/", "'IN_QQAPPKEY', '".SafeRequest("IN_QQAPPKEY","post")."'", $str);
$str=preg_replace("/'IN_REGOPEN', '(.*?)'/", "'IN_REGOPEN', '".SafeRequest("IN_REGOPEN","post")."'", $str);
$str=preg_replace("/'IN_SHAREOPEN', '(.*?)'/", "'IN_SHAREOPEN', '".SafeRequest("IN_SHAREOPEN","post")."'", $str);
$str=preg_replace("/'IN_ONLINEHOLD', '(.*?)'/", "'IN_ONLINEHOLD', '".SafeRequest("IN_ONLINEHOLD","post")."'", $str);
$str=preg_replace("/'IN_FEEDDAY', '(.*?)'/", "'IN_FEEDDAY', '".SafeRequest("IN_FEEDDAY","post")."'", $str);
$str=preg_replace("/'IN_FOOTPRINTDAY', '(.*?)'/", "'IN_FOOTPRINTDAY', '".SafeRequest("IN_FOOTPRINTDAY","post")."'", $str);
$str=preg_replace("/'IN_MESSAGEDAY', '(.*?)'/", "'IN_MESSAGEDAY', '".SafeRequest("IN_MESSAGEDAY","post")."'", $str);
$str=preg_replace("/'IN_LISTENDAY', '(.*?)'/", "'IN_LISTENDAY', '".SafeRequest("IN_LISTENDAY","post")."'", $str);
$str=preg_replace("/'IN_MAILDAY', '(.*?)'/", "'IN_MAILDAY', '".SafeRequest("IN_MAILDAY","post")."'", $str);
$str=preg_replace("/'IN_REGPOINTS', '(.*?)'/", "'IN_REGPOINTS', '".SafeRequest("IN_REGPOINTS","post")."'", $str);
$str=preg_replace("/'IN_REGRANK', '(.*?)'/", "'IN_REGRANK', '".SafeRequest("IN_REGRANK","post")."'", $str);
$str=preg_replace("/'IN_LOGINDAYPOINTS', '(.*?)'/", "'IN_LOGINDAYPOINTS', '".SafeRequest("IN_LOGINDAYPOINTS","post")."'", $str);
$str=preg_replace("/'IN_LOGINDAYRANK', '(.*?)'/", "'IN_LOGINDAYRANK', '".SafeRequest("IN_LOGINDAYRANK","post")."'", $str);
$str=preg_replace("/'IN_SIGNDAYPOINTS', '(.*?)'/", "'IN_SIGNDAYPOINTS', '".SafeRequest("IN_SIGNDAYPOINTS","post")."'", $str);
$str=preg_replace("/'IN_SIGNDAYRANK', '(.*?)'/", "'IN_SIGNDAYRANK', '".SafeRequest("IN_SIGNDAYRANK","post")."'", $str);
$str=preg_replace("/'IN_SIGNVIPOPEN', '(.*?)'/", "'IN_SIGNVIPOPEN', '".SafeRequest("IN_SIGNVIPOPEN","post")."'", $str);
$str=preg_replace("/'IN_AVATARPOINTS', '(.*?)'/", "'IN_AVATARPOINTS', '".SafeRequest("IN_AVATARPOINTS","post")."'", $str);
$str=preg_replace("/'IN_AVATARRANK', '(.*?)'/", "'IN_AVATARRANK', '".SafeRequest("IN_AVATARRANK","post")."'", $str);
$str=preg_replace("/'IN_MAILPOINTS', '(.*?)'/", "'IN_MAILPOINTS', '".SafeRequest("IN_MAILPOINTS","post")."'", $str);
$str=preg_replace("/'IN_MAILRANK', '(.*?)'/", "'IN_MAILRANK', '".SafeRequest("IN_MAILRANK","post")."'", $str);
$str=preg_replace("/'IN_MUSICINPOINTS', '(.*?)'/", "'IN_MUSICINPOINTS', '".SafeRequest("IN_MUSICINPOINTS","post")."'", $str);
$str=preg_replace("/'IN_MUSICINRANK', '(.*?)'/", "'IN_MUSICINRANK', '".SafeRequest("IN_MUSICINRANK","post")."'", $str);
$str=preg_replace("/'IN_SPECIALINPOINTS', '(.*?)'/", "'IN_SPECIALINPOINTS', '".SafeRequest("IN_SPECIALINPOINTS","post")."'", $str);
$str=preg_replace("/'IN_SPECIALINRANK', '(.*?)'/", "'IN_SPECIALINRANK', '".SafeRequest("IN_SPECIALINRANK","post")."'", $str);
$str=preg_replace("/'IN_SINGERINPOINTS', '(.*?)'/", "'IN_SINGERINPOINTS', '".SafeRequest("IN_SINGERINPOINTS","post")."'", $str);
$str=preg_replace("/'IN_SINGERINRANK', '(.*?)'/", "'IN_SINGERINRANK', '".SafeRequest("IN_SINGERINRANK","post")."'", $str);
$str=preg_replace("/'IN_VIDEOINPOINTS', '(.*?)'/", "'IN_VIDEOINPOINTS', '".SafeRequest("IN_VIDEOINPOINTS","post")."'", $str);
$str=preg_replace("/'IN_VIDEOINRANK', '(.*?)'/", "'IN_VIDEOINRANK', '".SafeRequest("IN_VIDEOINRANK","post")."'", $str);
$str=preg_replace("/'IN_MUSICOUTPOINTS', '(.*?)'/", "'IN_MUSICOUTPOINTS', '".SafeRequest("IN_MUSICOUTPOINTS","post")."'", $str);
$str=preg_replace("/'IN_MUSICOUTRANK', '(.*?)'/", "'IN_MUSICOUTRANK', '".SafeRequest("IN_MUSICOUTRANK","post")."'", $str);
$str=preg_replace("/'IN_SPECIALOUTPOINTS', '(.*?)'/", "'IN_SPECIALOUTPOINTS', '".SafeRequest("IN_SPECIALOUTPOINTS","post")."'", $str);
$str=preg_replace("/'IN_SPECIALOUTRANK', '(.*?)'/", "'IN_SPECIALOUTRANK', '".SafeRequest("IN_SPECIALOUTRANK","post")."'", $str);
$str=preg_replace("/'IN_SINGEROUTPOINTS', '(.*?)'/", "'IN_SINGEROUTPOINTS', '".SafeRequest("IN_SINGEROUTPOINTS","post")."'", $str);
$str=preg_replace("/'IN_SINGEROUTRANK', '(.*?)'/", "'IN_SINGEROUTRANK', '".SafeRequest("IN_SINGEROUTRANK","post")."'", $str);
$str=preg_replace("/'IN_VIDEOOUTPOINTS', '(.*?)'/", "'IN_VIDEOOUTPOINTS', '".SafeRequest("IN_VIDEOOUTPOINTS","post")."'", $str);
$str=preg_replace("/'IN_VIDEOOUTRANK', '(.*?)'/", "'IN_VIDEOOUTRANK', '".SafeRequest("IN_VIDEOOUTRANK","post")."'", $str);
if(!$fp = fopen('source/system/config.inc.php', 'w')){ShowMessage("����ʧ�ܣ��ļ�{source/system/config.inc.php}û��д��Ȩ�ޣ�",$_SERVER['HTTP_REFERER'],"infotitle3",3000,1);}
$ifile=new iFile('source/system/config.inc.php', 'w');
$ifile->WriteFile($str, 3);
ShowMessage("��ϲ�������ñ���ɹ���",$_SERVER['HTTP_REFERER'],"infotitle2",1000,1);
}
?>