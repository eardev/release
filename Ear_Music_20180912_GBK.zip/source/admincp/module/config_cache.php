<?php
if(!defined('IN_ROOT')){exit('Access denied');}
Administrator(2);
$action=SafeRequest("action","get");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo IN_CHARSET; ?>">
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title>ȫ������</title>
<link href="static/admincp/css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
function $(obj) {return document.getElementById(obj);}
function change(type){
        if(type==1){
            $('cacheopen').style.display='';
        }else if(type==2){
            $('cacheopen').style.display='none';
        }
}
</script>
</head>
<body>
<?php
switch($action){
	case 'save':
		save();
		break;
	default:
		main();
		break;
	}
?>
</body>
</html>
<?php function main(){ ?>
<script type="text/javascript">parent.document.title = 'EarCMS Board �������� - ȫ�� - ������Ϣ';if(parent.$('admincpnav')) parent.$('admincpnav').innerHTML='ȫ��&nbsp;&raquo;&nbsp;������Ϣ';</script>
<form method="post" action="?iframe=config_cache&action=save">
<input type="hidden" name="hash" value="<?php echo $_COOKIE['in_adminpassword']; ?>" />
<div class="container">
<div class="floattop"><div class="itemtitle"><h3>������Ϣ</h3><ul class="tab1">
<li><a href="?iframe=config"><span>վ����Ϣ</span></a></li>
<li class="current"><a href="?iframe=config_cache"><span>������Ϣ</span></a></li>
<li><a href="?iframe=config_upload"><span>�ϴ���Ϣ</span></a></li>
<li><a href="?iframe=config_pay"><span>֧����Ϣ</span></a></li>
<li><a href="?iframe=config_user"><span>��Ա��Ϣ</span></a></li>
</ul></div></div><div class="floattopempty"></div>
<table class="tb tb2">
<tr><th colspan="15" class="partition">ģ�建��</th></tr>
<tr><td colspan="2" class="td27">���濪��:</td></tr>
<tr><td class="vtop rowform">
<ul>
<?php if(IN_CACHEOPEN==1){echo "<li class=\"checked\">";}else{echo "<li>";} ?><input class="radio" type="radio" name="IN_CACHEOPEN" value="1" onclick="change(1);"<?php if(IN_CACHEOPEN==1){echo " checked";} ?>>&nbsp;����</li>
<?php if(IN_CACHEOPEN==0){echo "<li class=\"checked\">";}else{echo "<li>";} ?><input class="radio" type="radio" name="IN_CACHEOPEN" value="0" onclick="change(2);"<?php if(IN_CACHEOPEN==0){echo " checked";} ?>>&nbsp;�ر�</li>
</ul>
</td><td class="vtop tips2">�������������ģ�������Ч��</td></tr>
<tbody class="sub" id="cacheopen"<?php if(IN_CACHEOPEN<>1){echo " style=\"display:none;\"";} ?>>
<tr><td colspan="2" class="td27">����ʱ��:</td></tr>
<tr><td class="vtop rowform"><input type="text" class="txt" value="<?php echo IN_CACHETIME; ?>" name="IN_CACHETIME" onkeyup="this.value=this.value.replace(/[^\d]/g,'')" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[^\d]/g,''))"></td><td class="vtop tips2">��</td></tr>
</tbody>
</table>
<table class="tb tb2">
<tr><th colspan="15" class="partition">����ģʽ</th></tr>
<tr><td colspan="2" class="td27">α��̬����:</td></tr>
<tr><td class="vtop rowform">
<select name="IN_REWRITEOPEN">
<option value="0">��̬</option>
<option value="1"<?php if(IN_REWRITEOPEN==1){echo " selected";} ?>>α��̬</option>
<option value="2"<?php if(IN_REWRITEOPEN==2){echo " selected";} ?>>��̬</option>
</select>
</td><td class="vtop tips2">������ķ�������֧�� Rewrite����ѡ�񡰶�̬��</td></tr>
<tr><td colspan="15"><div class="fixsel"><input type="submit" class="btn" value="�ύ" /></div></td></tr>
</table>
</div>
</form>
<?php }function save(){
if(!submitcheck('hash', 1)){ShowMessage("������·�������޷��ύ��",$_SERVER['PHP_SELF'],"infotitle3",3000,1);}
$str=file_get_contents('source/system/config.inc.php');
$str=preg_replace("/'IN_CACHEOPEN', '(.*?)'/", "'IN_CACHEOPEN', '".SafeRequest("IN_CACHEOPEN","post")."'", $str);
$str=preg_replace("/'IN_CACHETIME', '(.*?)'/", "'IN_CACHETIME', '".SafeRequest("IN_CACHETIME","post")."'", $str);
$str=preg_replace("/'IN_REWRITEOPEN', '(.*?)'/", "'IN_REWRITEOPEN', '".SafeRequest("IN_REWRITEOPEN","post")."'", $str);
if(!$fp = fopen('source/system/config.inc.php', 'w')){ShowMessage("����ʧ�ܣ��ļ�{source/system/config.inc.php}û��д��Ȩ�ޣ�",$_SERVER['HTTP_REFERER'],"infotitle3",3000,1);}
$ifile=new iFile('source/system/config.inc.php', 'w');
$ifile->WriteFile($str, 3);
ShowMessage("��ϲ�������ñ���ɹ���",$_SERVER['HTTP_REFERER'],"infotitle2",1000,1);
}
?>